export { default } from './SectionTitle';
