export { default } from './FeaturedImage';
